**jrosrviztools** - Java module which allows to interact with RViz in ROS (Robotic Operation System).

# Download

You can download **jrosrviztools** release versions from <https://github.com/pinorobotics/jrosrviztools/releases>

Latest prerelease version can be found here <https://github.com/pinorobotics/jrosrviztools/tree/main/jrosrviztools/release>

# Contributors

aeon_flux <aeon_flux@eclipso.ch>
